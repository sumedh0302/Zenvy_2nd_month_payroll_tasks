import sqlite3

# define database file
DB = "payroll.db"

conn = sqlite3.connect(DB, timeout=30)

cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS payroll_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    status TEXT,
    created_at TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user TEXT,
    action TEXT,
    timestamp TEXT,
    before_value TEXT,
    after_value TEXT,
    status TEXT
)
""")

conn.commit()
conn.close()

print("Database and tables created successfully")