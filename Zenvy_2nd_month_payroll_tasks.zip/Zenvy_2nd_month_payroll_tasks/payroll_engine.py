import pandas as pd
import json
import sqlite3
from audit_logger import log_action

DB = "payroll.db"

# Dynamic Rule Loader

def load_salary_rules():

    with open("salary_rules.json") as f:
        rules = json.load(f)

    return rules["components"]

# Database Connection

def get_connection():

    conn = sqlite3.connect(DB)

    conn.execute("""
    CREATE TABLE IF NOT EXISTS payroll_runs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        status TEXT,
        created_at TEXT
    )
    """)

    conn.execute("""
    CREATE TABLE IF NOT EXISTS audit_logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user TEXT,
        action TEXT,
        timestamp TEXT,
        before_value TEXT,
        after_value TEXT,
        status TEXT
    )
    """)

    return conn

# Payroll Lock System

def check_payroll_lock(conn):

    cursor = conn.cursor()

    cursor.execute("SELECT status FROM payroll_runs WHERE status='RUNNING'")

    if cursor.fetchone():
        raise Exception("Payroll already running (LOCK active)")


def start_payroll_run(conn):

    conn.execute("""
    INSERT INTO payroll_runs(status,created_at)
    VALUES('RUNNING',datetime('now'))
    """)


def finish_payroll_run(conn):

    conn.execute("""
    UPDATE payroll_runs
    SET status='COMPLETED'
    WHERE status='RUNNING'
    """)

# Payroll Engine

class PayrollEngine:

    def __init__(self):

        self.rules = load_salary_rules()

    def calculate(self, employee, attendance):

        base_salary = employee["base_salary"]
        overtime = attendance["overtime_hours"]

        hra = base_salary * self.rules["hra_percentage"]
        overtime_pay = overtime * self.rules["overtime_rate_per_hour"]

        gross_salary = base_salary + hra + overtime_pay

        tax = gross_salary * self.rules["tax_percentage"]
        pf = gross_salary * self.rules["pf_percentage"]

        net_salary = gross_salary - tax - pf

        return {
            "employee_id": employee["employee_id"],
            "gross_salary": gross_salary,
            "tax_deduction": tax,
            "pf_deduction": pf,
            "net_salary": net_salary
        }

# High Volume Batch Processor

def process_payroll(user="admin"):

    conn = get_connection()

    try:

        conn.execute("BEGIN")

        check_payroll_lock(conn)

        start_payroll_run(conn)

        employees = pd.read_csv("zenvy_employees.csv")
        attendance = pd.read_csv("zenvy_attendance.csv")

        engine = PayrollEngine()

        results = []

        for _, emp in employees.iterrows():

            att = attendance[
                attendance.employee_id == emp.employee_id
            ]

            if att.empty:
                raise Exception("Missing attendance data")

            att = att.iloc[0]

            before = {"base_salary": emp.base_salary}

            payroll = engine.calculate(emp, att)

            results.append(payroll)
        log_action(
         conn,
         user,
         "PAYROLL_CALCULATION",
         before,
         payroll,
         "SUCCESS"
        )

        df = pd.DataFrame(results)

        df.to_csv("zenvy_payroll_output.csv", index=False)

        finish_payroll_run(conn)

        conn.commit()

        print("Payroll completed successfully")

    except Exception as e:

        conn.rollback()

        log_action(
            user,
            "PAYROLL_FAILED",
            {},
            {},
            "FAILED"
        )

        print("Error:", e)

    finally:

        conn.close()

# Run Payroll

if __name__ == "__main__":

    process_payroll()