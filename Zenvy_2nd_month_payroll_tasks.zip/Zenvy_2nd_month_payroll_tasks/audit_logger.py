from datetime import datetime

def log_action(conn, user, action, before_value, after_value, status):

    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO audit_logs
    (user, action, timestamp, before_value, after_value, status)
    VALUES (?, ?, ?, ?, ?, ?)
    """, (
        user,
        action,
        datetime.now().isoformat(),
        str(before_value),
        str(after_value),
        status
    ))